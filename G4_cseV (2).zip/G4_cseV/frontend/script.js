//slider
let currentIndex = 0;
function showSlide(index) {
    const slidesContainer = document.querySelector('.slides')
    const slides = document.querySelectorAll('.slide');
    if (index >= slides.length) {
        currentIndex = 0;
    }
    else if (index < 0) {
        currentIndex = slides.length - 1;
    }
    else {
        currentIndex = index;
    }
    const offset = -currentIndex * 100;
    slidesContainer.style.transform = `translateX(${offset}%)`;
}
function moveSlide(step) {
    showSlide(currentIndex + step);
}
setInterval(() => {
    moveSlide(1)
}, 3500);


//typerwriter

const typewriterTexts = ["Transforming Feedback into Growth Opportunities", "Insightful Reviews, Informed Choices", "Bridging the Gap Between Feedback and Success"];
let currentTextIndex = 0;
let isDeleting = false;
let charIndex = 0;
const typingSpeed = 10;
const deletingSpeed = 10;
const delayBetweenTyping = 2000;

function typeWriterEffect(texts, element) {
    const currentText = texts[currentTextIndex];

    if (isDeleting) {
        if (charIndex > 0) {
            charIndex--;
            element.innerHTML = currentText.substring(0, charIndex);
            setTimeout(() => typeWriterEffect(texts, element), deletingSpeed);
        } else {
            isDeleting = false;
            currentTextIndex = (currentTextIndex + 1) % texts.length;
            setTimeout(() => typeWriterEffect(texts, element), delayBetweenTyping);
        }
    } else {
        if (charIndex < currentText.length) {
            element.innerHTML = currentText.substring(0, charIndex + 1);
            charIndex++;
            setTimeout(() => typeWriterEffect(texts, element), typingSpeed);
        } else {
            isDeleting = true;
            setTimeout(() => typeWriterEffect(texts, element), delayBetweenTyping);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const typewriterElement = document.querySelector('.typewriter');
    typeWriterEffect(typewriterTexts, typewriterElement);
});



//portfolio

function startCounting(target, targetValue, unit) {
    let count = 0;
    const interval = setInterval(() => {
        if (count < targetValue) {
            count++;
            target.textContent = count + unit;
        } else {
            clearInterval(interval);
        }
    }, 1);
}

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const target = entry.target;
            const targetValue = parseInt(target.getAttribute('data-target'), 10);
            const unit = targetValue === 100 ? '%' : '+';
            startCounting(target, targetValue, unit);
            observer.unobserve(target);
        }
    });
}, { threshold: 1.0 });

document.querySelectorAll('.count').forEach(counter => {
    observer.observe(counter);
});
