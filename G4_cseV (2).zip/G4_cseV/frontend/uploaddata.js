// const allStar = document.querySelectorAll('.stars .bx1')

// allStar.forEach((item, idx)=> {
//     item.addEventListener('click', function(){
//         allStar.forEach(i=>{
//             i.classList.replace('bxs-star', 'bx-star')
//         })
//         for(let i =0; i<allStar.length; i++){
//             if(i<= idx){
//                 allStar[i].classList.replace('bx-star', 'bxs-star')
//             }
//         }
//     })
// })

// const allStar2 = document.querySelectorAll('.stars .bx2')

// allStar2.forEach((item, idx)=> {
//     item.addEventListener('click', function(){
//         allStar2.forEach(i=>{
//             i.classList.replace('bxs-star', 'bx-star')
//         })
//         for(let i =0; i<allStar2.length; i++){
//             if(i<= idx){
//                 allStar2[i].classList.replace('bx-star', 'bxs-star')
//             }
//         }
//     })
// })

// const allStar3 = document.querySelectorAll('.stars .bx3')

// allStar3.forEach((item, idx)=> {
//     item.addEventListener('click', function(){
//         allStar3.forEach(i=>{
//             i.classList.replace('bxs-star', 'bx-star')
//         })
//         for(let i =0; i<allStar3.length; i++){
//             if(i<= idx){
//                 allStar3[i].classList.replace('bx-star', 'bxs-star')
//             }
//         }
//     })
// })

// const allStar4 = document.querySelectorAll('.stars .bx4')

// allStar4.forEach((item, idx)=> {
//     item.addEventListener('click', function(){
//         allStar4.forEach(i=>{
//             i.classList.replace('bxs-star', 'bx-star')
//         })
//         for(let i =0; i<allStar4.length; i++){
//             if(i<= idx){
//                 allStar4[i].classList.replace('bx-star', 'bxs-star')
//             }
//         }
//     })
// })

// const allStar5 = document.querySelectorAll('.stars .bx5')

// allStar5.forEach((item, idx)=> {
//     item.addEventListener('click', function(){
//         allStar5.forEach(i=>{
//             i.classList.replace('bxs-star', 'bx-star')
//         })
//         for(let i =0; i<allStar5.length; i++){
//             if(i<= idx){
//                 allStar5[i].classList.replace('bx-star', 'bxs-star')
//             }
//         }
//     })
// })

// const allStar6 = document.querySelectorAll('.stars .bx6')

// allStar6.forEach((item, idx)=> {
//     item.addEventListener('click', function(){
//         allStar6.forEach(i=>{
//             i.classList.replace('bxs-star', 'bx-star')
//         })
//         for(let i =0; i<allStar6.length; i++){
//             if(i<= idx){
//                 allStar6[i].classList.replace('bx-star', 'bxs-star')
//             }
//         }
//     })
// })



// // Function to reset stars in any group
// function resetStars(starsGroup) {
//     starsGroup.forEach(star => {
//         star.classList.replace('bxs-star', 'bx-star');
//         totalRatingSpan.textContent = 0

//     });
// }

// // Add event listener to the reset button
// document.getElementById('reset-rating').addEventListener('click', () => {
//     const allStarGroups = [
//         document.querySelectorAll('.stars .bx1'),
//         document.querySelectorAll('.stars .bx2'),
//         document.querySelectorAll('.stars .bx3'),
//         document.querySelectorAll('.stars .bx4'),
//         document.querySelectorAll('.stars .bx5'),
//         document.querySelectorAll('.stars .bx6')
//     ];

//     allStarGroups.forEach(group => resetStars(group));
// });


// document.querySelector('.btn_submit').addEventListener('click', function(event) {
//     event.preventDefault();  // Prevent the default form submission
    
//     // Collect form data
//     const category = document.getElementById('category').value;
//     const name = document.getElementById('name').value;

//     // Collect ratings
//     const curriculumRating = document.querySelector('.bx1.bxs-star') ? 1 : 0;
//     const professorsRating = document.querySelector('.bx2.bxs-star') ? 1 : 0;
//     const environmentRating = document.querySelector('.bx3.bxs-star') ? 1 : 0;
//     const placementsRating = document.querySelector('.bx4.bxs-star') ? 1 : 0;
//     const messFoodRating = document.querySelector('.bx5.bxs-star') ? 1 : 0;
//     const infrastructureRating = document.querySelector('.bx6.bxs-star') ? 1 : 0;

//     const opinion = document.querySelector('textarea[name="opinion"]').value;

//     const totalRating = (curriculumRating + professorsRating + environmentRating + placementsRating + messFoodRating + infrastructureRating) / 6;
    
//     // Prepare the data to be sent
//     const data = {
//         category,
//         name,
//         ratings: {
//             curriculum: curriculumRating,
//             professors: professorsRating,
//             environment: environmentRating,
//             placements: placementsRating,
//             messFood: messFoodRating,
//             infrastructure: infrastructureRating
//         },
//         opinion,
//         totalRating
//     };

//     // Send data to the backend (using fetch API)
//     fetch('/submitReview', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(data)
//     })
//     .then(response => response.json())
//     .then(result => {
//         if (result.success) {
//             togglePopup();  // Show the popup after successful submission
//         } else {
//             alert('Failed to submit data');
//         }
//     })
//     .catch(error => {
//         console.error('Error:', error);
//         alert('An error occurred');
//     });
// });













// const totalRatingSpan = document.getElementById("total-rating");

// // Function to update total rating
// function updateTotalRating() {
//     // Count all stars with the 'bxs-star' class
//     const selectedStars = document.querySelectorAll('.stars .bxs-star').length;
    
//     // Calculate the average rating by dividing by 6
//     const averageRating = (selectedStars / 6).toFixed(2); // Adjust decimal places if needed

//     // Display the average rating
//     totalRatingSpan.textContent = averageRating;
// }

// // Function to handle star clicks and apply the rating logic
// function handleStarClicks(stars) {
//     stars.forEach((item, idx) => {
//         item.addEventListener('click', function() {
//             // Reset all stars in the group
//             stars.forEach(i => {
//                 i.classList.replace('bxs-star', 'bx-star');
//             });
//             // Set the selected stars up to the clicked star
//             for (let i = 0; i <= idx; i++) {
//                 stars[i].classList.replace('bx-star', 'bxs-star');
//             }
//             // Update the total rating after each click
//             updateTotalRating();
//         });
//     });
// }

// // Apply the star click handler to each rating group
// handleStarClicks(document.querySelectorAll('.stars .bx1'));
// handleStarClicks(document.querySelectorAll('.stars .bx2'));
// handleStarClicks(document.querySelectorAll('.stars .bx3'));
// handleStarClicks(document.querySelectorAll('.stars .bx4'));
// handleStarClicks(document.querySelectorAll('.stars .bx5'));
// handleStarClicks(document.querySelectorAll('.stars .bx6'));



// //popup

// function togglePopup() {
//     const popup = document.getElementById('popup-1');
//     popup.classList.toggle('active');
// }









































// Function to calculate the rating based on selected stars in a group
function getRatingFromGroup(starGroup) {
    let selectedStars = 0;
    for (let i = 0; i < starGroup.length; i++) {
        if (starGroup[i].classList.contains('bxs-star')) {
            selectedStars++;
        }
    }
    return selectedStars;  // Return the number of selected stars (1 to 5)
}

// Submit the review data
document.querySelector('.btn_submit').addEventListener('click', function (event) {
    event.preventDefault();  // Prevent the default form submission

    // Collect form data
    const category = document.getElementById('category').value;
    const name = document.getElementById('name').value;

    // Collect ratings for each category by counting selected stars
    const curriculumRating = getRatingFromGroup(document.querySelectorAll('.stars .bx1'));
    const professorsRating = getRatingFromGroup(document.querySelectorAll('.stars .bx2'));
    const environmentRating = getRatingFromGroup(document.querySelectorAll('.stars .bx3'));
    const placementsRating = getRatingFromGroup(document.querySelectorAll('.stars .bx4'));
    const messFoodRating = getRatingFromGroup(document.querySelectorAll('.stars .bx5'));
    const infrastructureRating = getRatingFromGroup(document.querySelectorAll('.stars .bx6'));

    const opinion = document.querySelector('textarea[name="opinion"]').value;

    // Calculate total rating
    const totalRating = (curriculumRating + professorsRating + environmentRating + placementsRating + messFoodRating + infrastructureRating) / 6;

    // Prepare the data to be sent
    const data = {
        category,
        name,
        ratings: {
            curriculum: curriculumRating,
            professors: professorsRating,
            environment: environmentRating,
            placements: placementsRating,
            messFood: messFoodRating,
            infrastructure: infrastructureRating
        },
        opinion,
        totalRating
    };

    // Send data to the backend (using fetch API)
    fetch('/submitReview', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            togglePopup();  // Show the popup after successful submission
        } else {
            alert('Failed to submit data');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred');
    });
});

// Function to update the total rating
function updateTotalRating() {
    // Count all stars with the 'bxs-star' class
    const selectedStars = document.querySelectorAll('.stars .bxs-star').length;
    
    // Calculate the average rating by dividing by 6
    const averageRating = (selectedStars / 6).toFixed(2); // Adjust decimal places if needed

    // Display the average rating
    totalRatingSpan.textContent = averageRating;
}

// Handle star rating clicks for each group of stars
function handleStarClicks(stars) {
    stars.forEach((item, idx) => {
        item.addEventListener('click', function () {
            // Reset all stars in the group
            stars.forEach(i => {
                i.classList.replace('bxs-star', 'bx-star');
            });
            // Set the selected stars up to the clicked star
            for (let i = 0; i <= idx; i++) {
                stars[i].classList.replace('bx-star', 'bxs-star');
            }
            // Update the total rating after each click
            updateTotalRating();
        });
    });
}

// Apply the star click handler to each rating group
handleStarClicks(document.querySelectorAll('.stars .bx1'));
handleStarClicks(document.querySelectorAll('.stars .bx2'));
handleStarClicks(document.querySelectorAll('.stars .bx3'));
handleStarClicks(document.querySelectorAll('.stars .bx4'));
handleStarClicks(document.querySelectorAll('.stars .bx5'));
handleStarClicks(document.querySelectorAll('.stars .bx6'));

// Reset stars on button click
document.getElementById('reset-rating').addEventListener('click', () => {
    const allStarGroups = [
        document.querySelectorAll('.stars .bx1'),
        document.querySelectorAll('.stars .bx2'),
        document.querySelectorAll('.stars .bx3'),
        document.querySelectorAll('.stars .bx4'),
        document.querySelectorAll('.stars .bx5'),
        document.querySelectorAll('.stars .bx6')
    ];

    allStarGroups.forEach(group => {
        group.forEach(star => {
            star.classList.replace('bxs-star', 'bx-star');
        });
    });
    totalRatingSpan.textContent = '0';
});

// popup toggle function
function togglePopup() {
    const popup = document.getElementById('popup-1');
    popup.classList.toggle('active');
}

// Function to toggle popup visibility
function togglePopup() {
    const popup = document.getElementById('popup-1');
    popup.classList.add('active'); // Ensure the popup is shown
}

// Close the popup when the user clicks "OK"
document.getElementById('popup-ok').addEventListener('click', function() {
    const popup = document.getElementById('popup-1');
    popup.classList.remove('active'); // Remove the "active" class to close the popup
});