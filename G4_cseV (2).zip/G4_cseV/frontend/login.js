document.getElementById('login-toggle').classList.add('active'); // Set login as the default active form
document.getElementById('login-form').classList.add('active');   // Show login form by default

function showLogin() {
  document.getElementById('login-toggle').classList.add('active');
  document.getElementById('signup-toggle').classList.remove('active');
  document.getElementById('login-form').classList.add('active');
  document.getElementById('signup-form').classList.remove('active');
}

function showSignup() {
  document.getElementById('signup-toggle').classList.add('active');
  document.getElementById('login-toggle').classList.remove('active');
  document.getElementById('signup-form').classList.add('active');
  document.getElementById('login-form').classList.remove('active');
}

// Handle login form submission
function handleLogin(event) {
  event.preventDefault();
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  // Add your login logic here
  alert(`Logged in as ${username}`);
}

// Handle signup form submission
function handleSignup(event) {
  event.preventDefault();

  const username = document.getElementById('signup-username').value;
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;

  fetch('http://localhost:5000/signup', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, email, password }),
  })
    .then((response) => {
      if (!response.ok) {
        // Handle errors from the backend
        return response.json().then((data) => {
          throw new Error(data.message || 'Error occurred');
        });
      }
      return response.json();
    })
    .then((data) => {
      // Success alert
      alert(data.message);
    })
    .catch((error) => {
      // Show error alert for existing user
      alert(error.message); 
    });
}
