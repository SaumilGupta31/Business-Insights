const mongoose = require('mongoose');

// Review schema
const reviewSchema = new mongoose.Schema({
    category: String,
    name: String,
    ratings: {
        curriculum: Number,
        professors: Number,
        environment: Number,
        placements: Number,
        messFood: Number,
        infrastructure: Number
    },
    opinion: String,
    totalRating: Number
});

const Review = mongoose.model('Review', reviewSchema);
module.exports = Review;
