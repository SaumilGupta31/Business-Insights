const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const path = require("path");
const Review = require('./models/reviews');
const User = require('./models/User');
const ExcelJS = require("exceljs");

// Create an instance of Express
const app = express();

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // Parse JSON bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies


const mongoURI = "mongodb://localhost:27017/ReviewsInfo"; 
mongoose
  .connect(mongoURI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));

const frontendPath = path.join(__dirname, "../frontend");
app.use(express.static(frontendPath));


// POST endpoint to handle form submission
app.post('/submitReview', (req, res) => {
    const { category, name, ratings, opinion, totalRating } = req.body;

    // Create a new review document
    const newReview = new Review({
        category,
        name,
        ratings,
        opinion,
        totalRating
    });

    // Save the review to MongoDB
    newReview.save()
    .then(() => {
        res.json({ success: true });
    })
    .catch(error => {
        console.error('Error saving review:', error);
        res.status(500).json({ success: false });
    });
});


// NEW: Route to get data and download as Excel
app.get("/download-data", async (req, res) => {
    try {
        // Fetch all reviews from MongoDB
        const reviews = await Review.find();

        // Create a new Excel workbook and worksheet
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet("Reviews");

        // Define columns for the worksheet, including individual ratings
        worksheet.columns = [
            { header: 'Category', key: 'category', width: 30 },
            { header: 'Name', key: 'name', width: 30 },
            { header: 'Curriculum', key: 'curriculum', width: 15 },
            { header: 'Professors', key: 'professors', width: 15 },
            { header: 'Environment', key: 'environment', width: 15 },
            { header: 'Placements', key: 'placements', width: 15 },
            { header: 'Mess Food', key: 'messFood', width: 15 },
            { header: 'Infrastructure', key: 'infrastructure', width: 15 },
            { header: 'Opinion', key: 'opinion', width: 30 },
            { header: 'Total Rating', key: 'totalRating', width: 15 },
        ];

        // Add the review data to the worksheet
        reviews.forEach(review => {
            worksheet.addRow({
                category: review.category,
                name: review.name,
                curriculum: review.ratings.curriculum,
                professors: review.ratings.professors,
                environment: review.ratings.environment,
                placements: review.ratings.placements,
                messFood: review.ratings.messFood,
                infrastructure: review.ratings.infrastructure,
                opinion: review.opinion,
                totalRating: review.totalRating
            });
        });

        // Set headers for file download
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', 'attachment; filename="reviews_data.xlsx"');

        // Write the Excel file to the response stream
        await workbook.xlsx.write(res);
        res.end();
    } catch (error) {
        console.error("Error generating Excel file:", error);
        res.status(500).send("Failed to generate Excel file.");
    }
});

// POST route to handle signup form submission
app.post('/signup', (req, res) => {
    const { username, email, password } = req.body;
  
    // Check if the username or email already exists
    User.findOne({ $or: [{ username }, { email }] })
      .then((existingUser) => {
        if (existingUser) {
          return res.status(400).json({ message: 'Username or email already taken' });
        }
  
        // Save the user if not exists
        const newUser = new User({ username, email, password });
  
        newUser.save()
          .then(() => {
            res.status(201).json({ message: 'User created successfully' });
          })
          .catch((error) => {
            res.status(500).json({ message: 'Error creating user', error });
          });
      })
      .catch((error) => {
        res.status(500).json({ message: 'Error checking user', error });
      });
  });
  


// Fallback Route for Single Page Applications (optional)
app.get("*", (req, res) => {
    res.sendFile(path.join(frontendPath, "index.html"));
  });

// Start the server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
